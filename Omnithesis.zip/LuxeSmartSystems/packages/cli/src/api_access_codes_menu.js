/* API keys menu */
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
/* API keys menu */